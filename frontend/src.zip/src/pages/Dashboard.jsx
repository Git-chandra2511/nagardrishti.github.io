import { Link } from 'react-router-dom'
import { ArrowRight, Camera, CheckCircle2, Clock3, MapPinned, Plus, ShieldCheck, Sparkles } from 'lucide-react'
import StatCard from '../components/StatCard'
import IssueCard from '../components/IssueCard'
import MapView from '../components/MapView'

export default function Dashboard({ reports, user }) {
  const verified = reports.filter(r => r.verified).length
  const active = reports.filter(r => ['Pending', 'In Progress'].includes(r.status)).length
  return (
    <div className="page">
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot" /> LIVE CIVIC NETWORK</div>
          <h1>Make your city <em>visible.</em></h1>
          <p>Nagar Drishti turns citizens into a real-time sensing network. Scan a civic problem, verify the AI, and send it to the right department.</p>
          <div className="hero-actions">
            <Link className="primary-btn" to="/scan"><Camera size={18} /> Report an issue <ArrowRight size={17} /></Link>
            <Link className="secondary-btn" to="/map"><MapPinned size={17} /> Explore map</Link>
          </div>
        </div>
        <div className="hero-orbit">
          <div className="orbit orbit-1" />
          <div className="orbit orbit-2" />
          <div className="scan-core"><ShieldCheck size={42} /><span>AI<br />CIVIC<br />VISION</span></div>
          <div className="orbit-tag tag-a"><CheckCircle2 size={14} /> Verified</div>
          <div className="orbit-tag tag-b"><Sparkles size={14} /> AI 94%</div>
          <div className="orbit-tag tag-c"><MapPinned size={14} /> GPS</div>
        </div>
      </section>

      <section className="stats-grid">
        <StatCard icon="AlertTriangle" label="Total reports" value={reports.length + 1038} detail="+12% this week" />
        <StatCard icon="Activity" label="Active issues" value={active + 23} detail="Across 4 departments" tone="cyan" />
        <StatCard icon="CheckCircle2" label="Verified reports" value={verified + 981} detail="94% verification rate" tone="green" />
        <StatCard icon="Trophy" label="Your Nagar Points" value={user.points} detail="+10 per verified report" tone="violet" />
      </section>

      <section className="dashboard-grid">
        <div className="panel map-panel">
          <div className="panel-head">
            <div><span className="panel-kicker">LIVE INTELLIGENCE</span><h2>Civic activity map</h2></div>
            <Link to="/map">Open full map <ArrowRight size={15} /></Link>
          </div>
          <div className="dashboard-map"><MapView reports={reports} /></div>
        </div>
        <div className="panel recent-panel">
          <div className="panel-head">
            <div><span className="panel-kicker">LATEST SIGNALS</span><h2>Recent issues</h2></div>
            <Link to="/feed">View all <ArrowRight size={15} /></Link>
          </div>
          <div className="issue-list">{reports.slice(0, 4).map(r => <IssueCard key={r.id} report={r} compact />)}</div>
          <Link className="quick-report" to="/scan"><Plus size={17} /> Report a new civic issue</Link>
        </div>
      </section>

      <section className="how-strip">
        <div><Clock3 size={18} /><span><strong>30 sec</strong> average report</span></div>
        <div><ShieldCheck size={18} /><span><strong>AI verified</strong> before submission</span></div>
        <div><MapPinned size={18} /><span><strong>GPS tagged</strong> for action</span></div>
      </section>
    </div>
  )
}
